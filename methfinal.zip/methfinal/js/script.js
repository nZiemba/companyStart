
window.addEventListener("load", function(){


});//dont close
